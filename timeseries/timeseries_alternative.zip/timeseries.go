package timeseries // import "goex/ltser/timeseries"

import (
	"time"
)

type myFloat64 float64

// TimeSeries represents an historical sequence of values.
type TimeSeries struct {
	times  []time.Time
	values []interface{}
}

// New returns a new TimeSeries.
func New() *TimeSeries {
	s := new(TimeSeries)
	s.times = make([]time.Time, 0)
	s.values = make([]interface{}, 0)

	return s
}

// AddWithTime records an observation at a specified time.
func (ts *TimeSeries) AddWithTime(v interface{}, t time.Time) {
	ts.times = append(ts.times, t)
	ts.values = append(ts.values, v)
}

// Add records an observation at the current time.
func (ts *TimeSeries) Add(v interface{}) {
	ts.AddWithTime(v, time.Now())
}

// Values returns the raw values of the series.
func (ts *TimeSeries) Values() []interface{} {
	return ts.values
}

// FloatValues returns the values of the series as float64.
func (ts *TimeSeries) FloatValues() []float64 {
	b := make([]float64, len(ts.values))
	for i := range ts.values {
		b[i] = ts.values[i].(float64)
	}
	return b
}
